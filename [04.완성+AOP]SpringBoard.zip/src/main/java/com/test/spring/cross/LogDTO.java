package com.test.spring.cross;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;


@Data
public class LogDTO {
	private String seq;
	private String url;
	private String id;
	private String regdate;
}

